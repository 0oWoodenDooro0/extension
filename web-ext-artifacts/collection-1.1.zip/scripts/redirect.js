function urlChangeHandler() {
  const urlString = window.location.href;
  const url = new URL(urlString);
  const params = url.searchParams;

  if (params.has('id') && params.size > 1) {
    const idValue = params.get('id');
    const newUrl = `${url.origin}${url.pathname}?id=${encodeURIComponent(idValue)}`;

    if (urlString !== newUrl) {
      window.location.href = newUrl;
    }
  }
}

window.addEventListener('popstate', urlChangeHandler);
window.addEventListener('hashchange', urlChangeHandler);

urlChangeHandler();
