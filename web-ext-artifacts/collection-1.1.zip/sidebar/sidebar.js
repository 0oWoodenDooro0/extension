document.addEventListener('DOMContentLoaded', () => {
    const createCollectionButton = document.getElementById('createCollectionButton')
    createCollectionButton.onclick = createCollection
    const exportCollectionButton = document.getElementById('exportCollectionButton')
    exportCollectionButton.onclick = exportCollections
    const importCollectionButton = document.getElementById('importCollectionButton')
    importCollectionButton.onclick = importCollections
    const fileInput = document.getElementById('fileInput')
    fileInput.addEventListener('change', (event) => {
        const file = event.target.files[0]
        if (file) {
            const reader = new FileReader()
            reader.onload = (e) => {
                try {
                    browser.storage.local.set({collections: JSON.parse(e.target.result)}, () => {
                        loadCollections()
                    })
                } catch (e) {
                    console.error('Error', e)
                }
            }
            reader.readAsText(file)
        }
    })
    const backToCollectionButton = document.getElementById('backToCollectionButton')
    backToCollectionButton.onclick = backToCollections
    const addToCollectionButton = document.getElementById('addToCollectionButton')
    addToCollectionButton.onclick = addToCollection
    const randomButton = document.getElementById('randomButton')
    randomButton.onclick = random

    const collectionList = document.getElementById('collectionList');
    const itemList = document.getElementById('itemList')
    const collectionsDiv = document.getElementById('collections')
    const itemsDiv = document.getElementById('items')

    let collections = [];
    let currentCollectionIndex = -1;

    function loadCollections() {
        browser.storage.local.get('collections', (data) => {
            collections = data.collections || [];
            displayCollections();
        });
    }

    function displayCollections() {
        collectionsDiv.style.display = 'block'
        itemsDiv.style.display = 'none'
        collectionList.innerHTML = '';
        for (let i = 0; i < collections.length; i++) {
            const listItem = document.createElement('li')
            const collectionText = document.createElement('span')
            collectionText.innerText = collections[i].title + `(${collections[i].items.length})`
            listItem.className = "collectionItem"
            listItem.addEventListener('click', () => {
                currentCollectionIndex = i
                displayCollectionItems()
            })
            listItem.appendChild(collectionText)

            const collectionSettings = document.createElement('div')
            collectionSettings.className = "collectionSettings"
            collectionSettings.innerText = "⚙️"

            const dropdown = document.createElement('div')
            dropdown.className = "dropdown-content"
            const renameItem = document.createElement('span')
            renameItem.innerText = "Rename"
            renameItem.addEventListener('click', (event) => {
                event.stopPropagation()
                showRenameInput(i)
            })
            const renameDiv = document.createElement('div')
            renameDiv.className = "rename-content"
            const renameInput = document.createElement('input')
            renameInput.className = "renameInput"
            renameInput.type = 'text'
            renameInput.addEventListener('click', (event) => {
                event.stopPropagation()
            })
            renameInput.value = collections[i].title
            const renameButton = document.createElement('button')
            renameButton.innerText = 'Save'
            renameButton.addEventListener('click', (event) => {
                event.stopPropagation()
                renameCollection(i)
            })
            renameDiv.appendChild(renameInput)
            renameDiv.appendChild(renameButton)

            const deleteItem = document.createElement('span')
            deleteItem.innerText = "Delete"
            deleteItem.addEventListener('click', (event) => {
                event.stopPropagation()
                deleteCollection(i)
            })
            listItem.appendChild(renameDiv)
            dropdown.appendChild(renameItem)
            dropdown.appendChild(deleteItem)
            collectionSettings.appendChild(dropdown)
            listItem.appendChild(collectionSettings)
            collectionList.appendChild(listItem)
        }
    }

    function displayCollectionItems() {
        collectionsDiv.style.display = 'none'
        itemsDiv.style.display = 'block'
        itemList.innerHTML = '';
        const currentItems = collections[currentCollectionIndex].items;
        const collectionTitle = document.getElementById('itemTitle')
        collectionTitle.innerText = collections[currentCollectionIndex].title
        for (let i = 0; i < currentItems.length; i++) {
            const listItem = document.createElement('li');
            const itemText = document.createElement('span')
            itemText.innerText = currentItems[i].title
            listItem.className = "collectionItem"
            listItem.addEventListener('click', () => {
                browser.tabs.create({url: currentItems[i].url});
            });
            listItem.appendChild(itemText)

            const itemSettings = document.createElement('div')
            itemSettings.className = "collectionSettings"
            itemSettings.innerText = "⚙️"

            const dropdown = document.createElement('div')
            dropdown.className = "dropdown-content"
            const deleteItem = document.createElement('span')
            deleteItem.innerText = "Delete"
            deleteItem.addEventListener('click', (event) => {
                event.stopPropagation()
                removeItem(i)
            })
            dropdown.appendChild(deleteItem)
            itemSettings.appendChild(dropdown)
            listItem.appendChild(itemSettings)
            itemList.appendChild(listItem)
        }
    }

    function addToCollection() {
        browser.tabs.query({active: true, currentWindow: true}, (tabs) => {
            const currentTab = tabs[0];
            if (currentTab && !checkDuplicateItem(collections[currentCollectionIndex].items, currentTab.url)) {
                collections[currentCollectionIndex].items.push({title: currentTab.title, url: currentTab.url})
                saveCollections()
                displayCollectionItems()
            }
        });
    }

    function checkDuplicateItem(items, url) {
        for (let key in items){
            if (items[key].url === url){
                return true
            }
        }
        return false
    }

    function backToCollections() {
        currentCollectionIndex = -1
        displayCollections()
    }

    function showRenameInput(index) {
        const renameDiv = collectionList.children[index].querySelector('.rename-content')
        renameDiv.style.display = 'inline-block'
        collectionList.children[index].children[0].innerText = ""
    }

    function renameCollection(index) {
        const renameInput = collectionList.children[index].querySelector('.renameInput')
        collections[index].title = renameInput.value
        saveCollections()
        displayCollections()
    }

    function deleteCollection(index) {
        collections.splice(index, 1)
        saveCollections()
        displayCollections()
    }

    function createCollection() {
        collections.push({title: "New Collection", items: []});
        saveCollections();
        displayCollections();
    }

    function removeItem(index) {
        const items = collections[currentCollectionIndex].items
        items.splice(index, 1)
        saveCollections()
        displayCollectionItems()
    }

    function random() {
        const items = collections[currentCollectionIndex].items
        browser.tabs.create({url: items[Math.floor((Math.random() * items.length))].url});
    }

    function exportCollections() {
        browser.storage.local.get('collections', (data) => {
            const collections = data.collections || {}
            const json = JSON.stringify(collections, null, 2)
            const blob = new Blob([json], {type: 'application/json'})
            const url = URL.createObjectURL(blob)

            const filename = `collections-backup-${new Date().toDateString().replaceAll(' ', '_')}.json`
            browser.downloads.download({
                url: url,
                filename: filename,
                saveAs: true
            }).then(() => {
                URL.revokeObjectURL(url)
            })
        })
    }

    function importCollections() {
        const fileInput = document.getElementById('fileInput')
        fileInput.click()
    }

    function saveCollections() {
        browser.storage.local.set({collections: collections});
    }

    loadCollections();
});